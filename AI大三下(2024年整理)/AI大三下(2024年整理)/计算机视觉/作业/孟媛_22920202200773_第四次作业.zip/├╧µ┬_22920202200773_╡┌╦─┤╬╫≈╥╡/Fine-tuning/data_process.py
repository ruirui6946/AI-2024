from pathlib import Path
import shutil
import random
import os
"""
文件结构如下：
    ./Fine-tuning
        ├── vgg16.py
        ├── resnet50.py
        ├── data_process.py
        ├── 15-scene #需要将数据集00-14文件夹存放在此目录下
            ├── 00
            ├── 01
            ...
            ├── 14
"""
data_dir = Path('./15-Scene')
train_dir = data_dir / 'train'
val_dir = data_dir / 'val'

# 创建训练集和测试集子目录
train_dir.mkdir(parents=True, exist_ok=True)
val_dir.mkdir(parents=True, exist_ok=True)

# 将每个类别的图像分成训练集和测试集
for class_dir in sorted(data_dir.glob('*')):
    if not class_dir.is_dir() or class_dir.name.startswith('.'):
        continue
    train_class_dir = train_dir / class_dir.name
    val_class_dir = val_dir / class_dir.name
    train_class_dir.mkdir(parents=True, exist_ok=True)
    val_class_dir.mkdir(parents=True, exist_ok=True)
    for image_file_path in sorted(class_dir.glob('*')):
        if not image_file_path.is_file() or image_file_path.name.startswith('.'):
            continue
        if random.random() < 0.8:
            target_file_path = train_class_dir / image_file_path.name
        else:
            target_file_path = val_class_dir / image_file_path.name
        if target_file_path.exists():
            target_file_path.unlink()
        target_file_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(image_file_path, target_file_path)

# 统计训练集和测试集中每个子目录的图像数量，并编写train.txt和val.txt
for x in ['train', 'val']:
    print(f"Size of {x}_set: {len(list((data_dir / x).glob('*/*')))}")
    with open(data_dir / f'{x}.txt', 'w') as f:
        for class_dir in sorted((data_dir / x).glob('*')):
            if not class_dir.is_dir() or class_dir.name.startswith('.'):
                continue
            for image_file_path in sorted(class_dir.glob('*')):
                if not image_file_path.is_file() or image_file_path.name.startswith('.'):
                    continue
                f.write(f"{class_dir.name}/{image_file_path.name}\n")
                
folders_to_delete = ["./15-Scene/train/train", "./15-Scene/train/val", "./15-Scene/val/train", "./15-Scene/val/val"]
for folder in folders_to_delete:
    if os.path.exists(folder):
        os.rmdir(folder)