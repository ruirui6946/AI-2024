import os
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
from torch.utils.data import DataLoader
from torchvision import datasets, models, transforms
import torch.optim as optim
from torch.optim.lr_scheduler import ReduceLROnPlateau
import torch
import torch.nn as nn


def train_model(model, data_loaders, criterion, optimizer, scheduler, num_epochs_train):
    # 检测是否有GPU，如果有则使用GPU，否则使用CPU
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # 将模型移动到GPU/CPU上
    model = model.to(device)
    # 记录最好的模型参数和准确率
    best_model_weights = model.state_dict()
    best_acc = 0.0

    # 循环训练num_epochs_train个epoch
    for epoch in range(num_epochs_train):
        print(f"\nEpoch {epoch + 1}/{num_epochs_train}:")
        # 在训练和验证数据集上循环
        for dataset_name in ['train', 'val']:
            # 如果是训练数据集，将模型设置为训练模式；否则设置为评估模式
            if dataset_name == 'train':
                model.train()
            else:
                model.eval()

            # 当前epoch的loss和准确率
            current_loss = 0
            current_corrects = 0

            # 在当前数据集上循环
            for inputs, labels in data_loaders[dataset_name]:
                # 将数据和标签移动到GPU/CPU上
                inputs = inputs.to(device)
                labels = labels.to(device)

                # 将梯度清零
                optimizer.zero_grad()

                # 根据当前模式计算输出和损失
                with torch.set_grad_enabled(dataset_name == 'train'):
                    outputs = model(inputs)
                    _, predictions = torch.max(outputs, 1)
                    loss = criterion(outputs, labels)

                    # 如果是训练数据集，反向传播并更新模型参数
                    if dataset_name == 'train':
                        loss.backward()
                        optimizer.step()

                # 计算当前batch的loss和准确率
                current_loss += loss.item() * inputs.size(0)
                current_corrects += torch.sum(predictions == labels.data)

            # 计算当前epoch的平均loss和准确率
            epoch_loss = current_loss / len(data_loaders[dataset_name].dataset)
            epoch_acc = current_corrects.double(
            ) / len(data_loaders[dataset_name].dataset)

            # 打印当前数据集的loss和准确率
            print(
                f"{dataset_name} Loss: {epoch_loss:.4f} | {dataset_name} Accuracy: {epoch_acc:.4f}")

            # 如果当前是验证数据集且准确率比最好的模型还要高，更新最好的模型参数和准确率
            if dataset_name == 'val' and epoch_acc > best_acc:
                best_acc = epoch_acc
                best_model_weights = model.state_dict()

            # 学习率调度器进行调整
            scheduler.step(epoch_loss)

    # 加载最好的模型参数
    model.load_state_dict(best_model_weights)
    return model



def evaluate_model(model, data_loaders, class_name):
    # 判断是否使用GPU进行训练，如果可用则使用GPU，否则使用CPU
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    # 将模型加载到设备中
    model = model.to(device)
    # 设置模型为评估模式
    model.eval()

    # 初始化真实标签和预测标签列表
    true_labels = []
    predicted_labels = []

    # 在不需要计算梯度的情况下进行推断
    with torch.no_grad():
        # 遍历验证数据集
        for inputs, labels in data_loaders['val']:
            # 将数据和标签放到设备上
            inputs = inputs.to(device)
            labels = labels.to(device)

            # 使用模型进行前向传播
            outputs = model(inputs)
            # 取最大值对应的类别作为预测类别
            _, predictions = torch.max(outputs, 1)

            # 将当前batch的真实标签和预测标签添加到对应列表中
            true_labels.extend(labels.cpu().numpy())
            predicted_labels.extend(predictions.cpu().numpy())

    # 计算混淆矩阵
    confusion_mtx = confusion_matrix(true_labels, predicted_labels)

    # 打印混淆矩阵
    print('Confusion Matrix:')
    print(confusion_mtx)

    # 绘制混淆矩阵图
    fig, confusion_matrix_ax = plt.subplots(figsize=(10, 10))
    confusion_matrix_ax.imshow(confusion_mtx, cmap=plt.cm.Blues)
    confusion_matrix_ax.set_xticks(np.arange(len(class_name)))
    confusion_matrix_ax.set_yticks(np.arange(len(class_name)))
    confusion_matrix_ax.set_xticklabels(class_name)
    confusion_matrix_ax.set_yticklabels(class_name)
    confusion_matrix_ax.tick_params(axis='x', labelrotation=90)

    for i in range(len(class_name)):
        for j in range(len(class_name)):
            confusion_matrix_ax.text(j, i, confusion_mtx[i, j], ha='center', va='center',
                                     color='white' if confusion_mtx[i, j] > confusion_mtx.max() / 2 else 'black')

    # 设置x轴和y轴的标签
    plt.xlabel('Predicted label')
    plt.ylabel('True label')
    # 展示混淆矩阵图
    plt.show()
    # 将混淆矩阵图保存到本地
    plt.savefig('./Resnet50 Confusion Matrix.jpg')


if __name__ == '__main__':
    # 定义数据预处理方式
    data_transforms = {
        'train': transforms.Compose([
            transforms.RandomResizedCrop(224),  # 随机裁剪并调整大小
            transforms.RandomHorizontalFlip(),  # 随机水平翻转
            transforms.ToTensor(),              # 转换为张量
            transforms.Normalize([0.485, 0.456, 0.406], [
                                 0.229, 0.224, 0.225])  # 标准化
        ]),
        'val': transforms.Compose([
            transforms.Resize(256),              # 调整大小
            transforms.CenterCrop(224),          # 中心裁剪
            transforms.ToTensor(),               # 转换为张量
            transforms.Normalize([0.485, 0.456, 0.406], [
                                 0.229, 0.224, 0.225])  # 标准化
        ]),
    }

    # 定义数据集路径
    dataset_dir = './15-Scene'
    # 加载训练集和验证集的图像
    images = {x: datasets.ImageFolder(os.path.join(
        dataset_dir, x), data_transforms[x]) for x in ['train', 'val']}
    # 加载训练集和验证集的数据集
    data_loaders = {x: DataLoader(
        images[x], batch_size=32, shuffle=True, num_workers=0) for x in ['train', 'val']}
    # 计算训练集和验证集的大小
    size = {x: len(images[x]) for x in ['train', 'val']}
    # 获取类别名称
    class_name = images['train'].classes
    # 加载预训练好的resnet50模型
    model = models.resnet50(pretrained=True)
    # 获取全连接层的输入特征数量
    num_ftrs = model.fc.in_features
    # 将全连接层替换成新的，输出特征数量为分类数目
    model.fc = nn.Linear(num_ftrs, len(data_loaders['train'].dataset.classes))
    # 定义损失函数
    criterion = nn.CrossEntropyLoss()
    # 定义优化器
    optimizer = optim.SGD(model.parameters(), lr=0.001, momentum=0.9)
    # 定义学习率调度器
    scheduler = ReduceLROnPlateau(
        optimizer, mode='min', factor=0.1, patience=5, verbose=True)
    # 定义训练轮数
    num_epochs_train = 25
    # 训练模型
    train_model(model, data_loaders, criterion,
                optimizer, scheduler, num_epochs_train)
    # 评估模型
    evaluate_model(model, data_loaders, class_name)
