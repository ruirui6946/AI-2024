"""
文件结构如下：
    ./Fine-tuning
        ├── vgg16.py
        ├── resnet50.py
        ├── data_process.py
        ├── 15-scene #需要将数据集00-14文件夹存放在此目录下
            ├── 00
            ├── 01
            ...
            ├── 14
"""
1. 运行data_process.py
2. 分别运行vgg16.py 和 resnet50.py