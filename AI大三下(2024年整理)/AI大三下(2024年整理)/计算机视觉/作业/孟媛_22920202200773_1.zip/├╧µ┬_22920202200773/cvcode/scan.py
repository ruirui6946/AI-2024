import cv2 # 计算机视觉
import numpy as np
import pytesseract # 实现OCR文档转文字
from PIL import Image # 处理图像
from spellchecker import SpellChecker # 拼写修正

#-----------------------函数定义---------------------------#
# 同比例变化方法
def resize_image(pic, height):
    """
    对图像进行同比例变化，返回调整后的图像
    :param image: 原始图像
    :param height: 目标高度
    :return: 调整后的图像
    """
    (h, w, s) = pic.shape
    scale = h/height
    image = cv2.resize(pic, (int(w/scale), height, ))
    return image


# 图像显示
def show_image(name, img):
    """
    在窗口中展示图像
    :param name: 窗口名称
    :param image: 待展示图像
    """
    cv2.imshow(name, img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def point_sorter(pts):
    """
    对四个点的列表进行排序，通过计算四个点的位置关系，
    找出它们在矩形中的位置，从而得到正确的顺序
    :param pts: 四个点的列表
    :return: 排序后的四个点
    """
    # 一共四个坐标点,创建一个坐标点都是零的二维点值
    rect = np.zeros((4, 2), dtype="float32")
    # 计算左上，右下
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]
    # 计算右上和左下
    diff = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(diff)]
    rect[3] = pts[np.argmax(diff)]
    return rect



# 透视变换
def Perspective_transformation(image, pts):
    """
    对图像进行透视变换
    :param image: 原始图像
    :param pts: 四个点的列表
    :return: 变换后的图像
    """
    # 获取坐标点
    rect = point_sorter(pts)
    (tl, tr, br, bl) = rect
    # 计算输入的w和h值
    widthA = np.sqrt(((br[0]-bl[0])**2)+((br[1]-br[1])**2))
    widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tr[1]) ** 2))
    maxWidth = max(int(widthA), int(widthB))
    heightA = np.sqrt(((tr[0]-br[0])**2)+((tr[1]-br[1])**2))
    heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
    maxHeight = max(int(heightA), int(heightB))
    # 变换后对应坐标位置
    dst = np.array([
        [0, 0],
        [maxWidth-1, 0],
        [maxWidth-1, maxHeight-1],
        [0, maxHeight-1]], dtype="float32")
    # 计算变换矩阵
    M = cv2.getPerspectiveTransform(rect, dst)
    # 将变换矩阵M带入函数warpPerspective，还有输入坐标计算出最大的宽和高
    warped = cv2.warpPerspective(image, M, (maxWidth, maxHeight))
    return warped
#-----------------------------------------------------------#


if __name__ == '__main__':
    #----------------读入图像并重置大小------------------#
    image = cv2.imread(r"input.jpg")
    ratio = image.shape[0]/500.0
    # 创建副本
    ini_image = image.copy()
    # resize_image大小
    image = resize_image(ini_image, 500)


    #------------------1.边缘检测----------------------#
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) # 转灰度图像
    gray = cv2.GaussianBlur(gray, (3, 3), 0)  # 高斯滤波，去噪音点
    edge = cv2.Canny(gray, 30, 180)  # Canny边缘检测
    # 显示预处理结果
    print('1.完成边缘检测!')
    show_image('edge', edge)


    #------------------2.轮廓检测----------------------#
    edges, hierarchy = cv2.findContours(edge.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE) # 获取轮廓
    edges = sorted(edges, key=cv2.contourArea, reverse=True)[:5] # 按面积排序取前五个
    for c in edges: # 遍历轮廓
        peri = cv2.arcLength(c, True) # 计算封闭的轮廓周长
        # 轮廓近似0.02*peri(原始轮廓到近似轮廓的最大距离)
        approx = cv2.approxPolyDP(c, 0.02*peri, True)
        if len(approx) == 4: # 如果检测到矩形的四个角点
            real_edge = approx
            break
    # 显示结果
    print('2.已成功获取轮廓!')
    cv2.drawContours(image, [real_edge], -1, (0, 255, 0), 2)
    show_image('image', image)
    new_h = real_edge.reshape(4, 2)*ratio


    #---------------------3.透视变换-----------------------------#
    warped = Perspective_transformation(ini_image, real_edge.reshape(4, 2)*ratio)
    warped = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY) # 转灰度图像
    ref = cv2.threshold(warped, 160, 255, cv2.THRESH_BINARY)[1] # 二值处理
    cv2.imwrite('output.png', ref) # 生成扫描结果图像
    print("3.已完成透视变换!请查看output.png文件")



    #----------------4.文档扫描与拼写修正-------------------------#
    spell = SpellChecker() # 加载拼写检查器
    img = Image.open('output.png')
    text = pytesseract.image_to_string(img, lang='eng') # 使用pytesseract将图片转换为文本
    with open("output_ini.txt", "w", encoding='utf-8') as f: # 将原始文档内容写入文件
        f.write(text)
    
    words = text.split()# 通过空格分割文本为单词列表
    # 对单词进行拼写检查和修正
    for word in words:
        if word:
            if word.isalpha() and len(word) > 1:  # 只检查字母且长度大于1的单词
                text = text.replace(word, str(spell.correction(word)))
    with open("output_corrected.txt", "w", encoding='utf-8') as f: # 修正后的内容写入文件
        f.write(text)
    print("4.已完成文档扫描及拼写修正!请查看output_corrected.txt")