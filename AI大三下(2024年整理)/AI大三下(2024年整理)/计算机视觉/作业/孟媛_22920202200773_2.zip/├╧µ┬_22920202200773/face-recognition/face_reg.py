import cv2
import face_recognition as fr
import os

def load_known_image():
    res = []
    for dir, dir_list, file_list in os.walk('./known_faces'):
        for filename in file_list:
            name = filename.split('.')[0]
            print(f'Loading image of {name}')
            res.append((name, fr.load_image_file(os.path.join(dir, filename))))
    return res

if __name__ == '__main__':
    print('Initializing...')
    faces = load_known_image()
    print('Encoding faces...(This may take a while)')
    known_face_encodings = [fr.face_encodings(i)[0] for _, i in faces]
    known_face_names = [i for i, _ in faces]

    print('Start to capture video...')
    cv2.namedWindow('img', cv2.WINDOW_NORMAL)
    cap = cv2.VideoCapture(0)
    ok = True
    while ok:
        ok, origin_img = cap.read()

        for face_location, unknown_face_encoding in zip(fr.face_locations(origin_img), fr.face_encodings(origin_img)):
            results = fr.compare_faces(known_face_encodings, unknown_face_encoding)

            if True in results:
                match = known_face_names[results.index(True)]
            else:
                match = 'Unknown'
            cv2.rectangle(origin_img, (face_location[3], face_location[0]), (face_location[1], face_location[2]), (255, 0, 0), 2)
            cv2.putText(origin_img, match, (face_location[3], face_location[0]), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)

        cv2.imshow('img', origin_img)
        key = cv2.waitKey(1)
        if key == 27:
            break
        
