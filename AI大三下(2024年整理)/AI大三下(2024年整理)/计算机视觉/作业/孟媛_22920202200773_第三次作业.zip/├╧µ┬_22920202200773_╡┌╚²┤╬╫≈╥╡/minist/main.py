import torch
import torch.nn as nn
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.datasets as datasets
import torchvision.transforms as transforms
from torch.utils.data import DataLoader

# 定义一些超参数
batch_size = 64
learning_rate = 0.01
num_epochs = 10


# 加载MNIST数据集
train_dataset = datasets.MNIST(root='data/',
                               train=True,
                               transform=transforms.ToTensor(),
                               download=True)

test_dataset = datasets.MNIST(root='data/',
                              train=False,
                              transform=transforms.ToTensor(),
                              download=True)


# 创建数据加载器
train_loader = DataLoader(dataset=train_dataset,
                          batch_size=batch_size,
                          shuffle=True)

test_loader = DataLoader(dataset=test_dataset,
                         batch_size=batch_size,
                         shuffle=False)


# 定义多层全连接神经网络
class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()
        self.fc1 = nn.Linear(28 * 28, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, 10)

    def forward(self, x):
        x = x.view(-1, 28 * 28)
        x = self.fc1(x)
        x = nn.functional.relu(x)
        x = self.fc2(x)
        x = nn.functional.relu(x)
        x = self.fc3(x)
        return x


# 定义卷积神经网络
class CNN(nn.Module):
    def __init__(self):
        super(CNN, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.fc1 = nn.Linear(64 * 7 * 7, 128)
        self.fc2 = nn.Linear(128, 10)

    def forward(self, x):
        x = self.conv1(x)
        x = nn.functional.relu(x)
        x = self.pool(x)
        x = self.conv2(x)
        x = nn.functional.relu(x)
        x = self.pool(x)
        x = x.view(-1, 64 * 7 * 7)
        x = self.fc1(x)
        x = nn.functional.relu(x)
        x = self.fc2(x)
        return x
    
    
# 定义损失函数和优化器
mlp_model = MLP()
cnn_model = CNN()
criterion = nn.CrossEntropyLoss()
mlp_optimizer = optim.SGD(mlp_model.parameters(), lr=learning_rate)
cnn_optimizer = optim.SGD(cnn_model.parameters(), lr=learning_rate)


# 训练多层全连接神经网络
for epoch in range(num_epochs):
    for batch_idx, (data, targets) in enumerate(train_loader):
        # 前向传播
        mlp_predictions = mlp_model(data)
        loss = criterion(mlp_predictions, targets)

        # 反向传播
        mlp_optimizer.zero_grad()
        loss.backward()
        mlp_optimizer.step()

        if batch_idx % 100 == 0:
            print(f'MLP: Epoch [{epoch}/{num_epochs}], Step [{batch_idx}/{len(train_loader)}], Loss: {loss.item():.4f}')


# 训练卷积神经网络
for epoch in range(num_epochs):
    for batch_idx, (data, targets) in enumerate(train_loader):
        # 前向传播
        cnn_predictions = cnn_model(data)
        loss = criterion(cnn_predictions, targets)

        # 反向传播
        cnn_optimizer.zero_grad()
        loss.backward()
        cnn_optimizer.step()

        if batch_idx % 100 == 0:
            print(f'CNN: Epoch [{epoch}/{num_epochs}], Step [{batch_idx}/{len(train_loader)}], Loss: {loss.item():.4f}')


# 在测试数据集上评估模型
def evaluate(model, loader):
    correct = 0
    total = 0
    model.eval()
    with torch.no_grad():
        for data, targets in loader:
            predictions = model(data)
            _, predicted = torch.max(predictions.data, 1)
            total += targets.size(0)
            correct += (predicted == targets).sum().item()
    return (correct / total) * 100

if __name__ == '__main__':
    mlp_accuracy = evaluate(mlp_model, test_loader)
    cnn_accuracy = evaluate(cnn_model, test_loader)
    print(f'MLP accuracy: {mlp_accuracy:.2f}%')
    print(f'CNN accuracy: {cnn_accuracy:.2f}%')
