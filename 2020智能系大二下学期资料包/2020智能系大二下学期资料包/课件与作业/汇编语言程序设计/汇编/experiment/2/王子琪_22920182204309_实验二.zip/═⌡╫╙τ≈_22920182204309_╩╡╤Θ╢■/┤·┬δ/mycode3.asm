; multi-segment executable file template.

data segment
    ; add your data here! 
    X dw 1710H
    Y dw 3343H
    Z dw 1234H
    V dW 8831H 
    ans dd 0H 
    pkey db "press any key...$"
ends
code segment
start:
; set segment registers:
    mov ax, data
    mov ds, ax
    mov es, ax

    mov ax,X
    imul Y
    mov cx, ax
    mov bx, dx
    mov ax, Z
    add cx, Z
    adc bx, 0
    sub cx, 540
    sbb bx, 0
    mov ax, V 
    cwd
    sub ax, cx
    sbb dx, bx
    idiv X
    mov ans, ax
    mov ans+2, dx
       
ends

end start ; set entry point and stop the assembler.
