; multi-segment executable file template.

data segment
    ; add your data here! 
    Data1 db 0C2H
    Data2 db 5FH
    Res1 dw 0H 
    Res2 dw 0H
    Res3 dw 0H
    Res4 dw 0H
ends

stack segment
    dw   128  dup(0)
ends

code segment
start:
; set segment registers:
    mov ax, data
    mov ds, ax
    mov es, ax
    mov ax,0
    ; add your code here
            
    mov al, Data1
    add al, Data2
    adc ah, 0
    mov Res1, ax
    mov ax,0
    
    mov al, Data1
    sub al, Data2
    mov Res2, ax 
    mov ax,0
    
    mov al, Data1
    MUL Data2
    mov Res3, ax
    mov ax,0   
    
    add ax, 0
    
    mov al, Data1
    DIV Data2
    mov Res4,ax
ends

end start ; set entry point and stop the assembler.
