; multi-segment executable file template.

data segment
    ; add your data here!
    Data1 db 56H, 34H, 12H
    Data2 db 0F1H, 4BH, 65H
    ans dd 0H
ends

stack segment
    dw   128  dup(0)
ends

code segment
start:
; set segment registers:
    mov ax, data
    mov ds, ax
    mov es, ax

    mov al, Data1
    mov ah, Data1+1
    mov dl, Data1+2 
    
    mov cl, Data2
    mov ch, Data2+1
    mov bl, Data2+2
    
    add al, cl
    adc ah, ch
    adc dl, bl
    adc dh, 0
    
    mov ans, ax
    mov ans+2, dx
ends

end start ; set entry point and stop the assembler.
