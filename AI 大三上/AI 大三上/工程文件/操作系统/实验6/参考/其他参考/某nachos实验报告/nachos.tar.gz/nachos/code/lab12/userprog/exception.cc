// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "syscall.h"

//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// And don't forget to increment the pc before returning. (Or else you'll
// loop making the same system call forever!
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	are in machine.h.
//----------------------------------------------------------------------

void
ExceptionHandler(ExceptionType which)
{
    int type = machine->ReadRegister(2);
    if ((which == SyscallException) && (type == SC_Halt)) {
	    DEBUG('a', "Shutdown, initiated by user program.\n");
   	 interrupt->Halt();
    }
 if ((which == SyscallException) && (type == SC_Exec)) {
	   DEBUG('a', "Shutdown, initiated by user program.\n");
   	int paraAddr=machine->ReadRegister(4);
      char para[20];
      for(int i=0;i<5;i++)
         {
      machine->ReadMem(paraAddr+4*i,4,(int*)(para+4*i));
         }
      extern void StartProcess(char *para);
      StartProcess(para);
      machine->registers[PCReg]=machine->registers[NextPCReg];
          } 
    else if(which==PageFaultException)
{
       stats->numPageFaults++;
       int i;
       int virtAdd=machine->registers[BadVAddrReg];
       int vpn = (unsigned) virtAdd / PageSize;
       printf("PageFault:CurrentThread VirtualPage %d fault...\n",vpn);
       printf("Current free physicalPage count is%d\n",machine->MemPageTable->NumClear());
       int phyPage=NumPhysPages-1;
       Thread* pt=NULL;
       //查找是否有空白页
       int fbn=machine->MemPageTable->Find();
       if(fbn!=-1)
       {
           phyPage=fbn;
           machine->MemPageTable->Set(fbn);
       }
       else
       {
           pt=(Thread*)machine->MemPageTable->GetOwner(NumPhysPages-1);
           //根据LRU算法寻找置换页
           int mintime=machine->MemPageTable->GetTime(NumPhysPages-1);

           for(i=NumPhysPages-1;i>=0;i--)
           {
               if(machine->MemPageTable->GetTime(i)<=mintime)
               {
printf("gettime %d \t%d\n",mintime,i);
                   phyPage=i;
                   mintime=machine->MemPageTable->GetTime(i);
                   pt=(Thread*)machine->MemPageTable->GetOwner(i);
               }
           }
       }
       //建立内存块缓存
       char buffer[PageSize];
       char buffer1[PageSize];
       for(i=0;i<PageSize;i++)
       {
           buffer[i]=machine->mainMemory[phyPage*PageSize+i];
       }
       //查找目标虚存页
       int virtPage=currentThread->space->pageTable[vpn].virtualPage;
       machine->vm->Read(virtPage,buffer1);
       for(i=0;i<PageSize;i++)
       {
           machine->mainMemory[phyPage*PageSize+i]=buffer1[i];
       }
       machine->MemPageTable->SetCounter(phyPage,0);
       machine->MemPageTable->SetTime(phyPage,stats->totalTicks);
//printf("settime %d\n",stats->totalTicks);
       machine->MemPageTable->SetOwner(phyPage,(int*)currentThread);
       if(pt!=NULL)
     {
           machine->vm->Write(virtPage,buffer);
           int index=0;
           for(i=0;i<pt->space->numPages;i++)
           {
               if(pt->space->pageTable[i].physicalPage==phyPage)
                   index=i;
           }
          ASSERT(pt->space->pageTable[index].physicalPage==phyPage);
          //写回
           pt->space->pageTable[index].valid=false;
           pt->space->pageTable[index].use=false;
           pt->space->pageTable[index].dirty=false;
           pt->space->pageTable[index].virtualPage=virtPage;
       }
       //写入
       currentThread->space->pageTable[vpn].valid=true;
       currentThread->space->pageTable[vpn].use=false;
       currentThread->space->pageTable[vpn].dirty=false;
       currentThread->space->pageTable[vpn].physicalPage=phyPage;
      if(fbn==-1)
           printf("***LRU算法*** \n Exchanging PhysicalPage phyPage:%d withVirtualPage:%d \n",phyPage,virtPage);
       else
           printf("Loading into PhysicalPage phyPage:%d from VirtualPage:%d\n",phyPage,virtPage);
}
 /************Over*******************/



    else {
	    printf("Unexpected user mode exception %d %d\n", which, type);
	    ASSERT(FALSE);
            }   
}
