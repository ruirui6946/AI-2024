arch/unknown-i386-linux/depends/interrupt.d arch/unknown-i386-linux/objects/interrupt.o: ../machine/interrupt.cc ../threads/copyright.h \
  ../machine/interrupt.h ../threads/list.h ../threads/copyright.h \
  ../threads/utility.h ../threads/bool.h ../machine/sysdep.h \
  ../threads/system.h ../threads/thread.h ../machine/machine.h \
  ../threads/utility.h ../machine/translate.h ../machine/disk.h \
  ../userprog/addrspace.h ../threads/copyright.h ../filesys/filesys.h \
  ../threads/copyright.h ../filesys/openfile.h ../threads/utility.h \
  ../threads/scheduler.h ../threads/list.h ../machine/timer.h \
  ../machine/interrupt.h ../machine/stats.h ../filesys/filesys.h
