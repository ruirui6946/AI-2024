arch/unknown-i386-linux/depends/disk.d arch/unknown-i386-linux/objects/disk.o: ../machine/disk.cc ../threads/copyright.h ../machine/disk.h \
  ../threads/utility.h ../threads/copyright.h ../threads/bool.h \
  ../machine/sysdep.h ../threads/system.h ../threads/utility.h \
  ../threads/thread.h ../threads/scheduler.h ../threads/list.h \
  ../machine/interrupt.h ../threads/list.h ../machine/stats.h \
  ../machine/timer.h ../lab11/filesys.h ../threads/copyright.h \
  ../lab11/openfile.h ../threads/utility.h ../lab11/synchdisk.h \
  ../machine/disk.h ../threads/synch.h
