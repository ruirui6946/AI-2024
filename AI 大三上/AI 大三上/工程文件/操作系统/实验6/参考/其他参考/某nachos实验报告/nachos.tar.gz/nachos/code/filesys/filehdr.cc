// filehdr.cc 
//	Routines for managing the disk file header (in UNIX, this
//	would be called the i-node).
//
//	The file header is used to locate where on disk the 
//	file's data is stored.  We implement this as a fixed size
//	table of pointers -- each entry in the table points to the 
//	disk sector containing that portion of the file data
//	(in other words, there are no indirect or doubly indirect 
//	blocks). The table size is chosen so that the file header
//	will be just big enough to fit in one disk sector, 
//
//      Unlike in a real system, we do not keep track of file permissions, 
//	ownership, last modification date, etc., in the file header. 
//
//	A file header can be initialized in two ways:
//	   for a new file, by modifying the in-memory data structure
//	     to point to the newly allocated data blocks
//	   for a file already on disk, by reading the file header from disk
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"

#include "system.h"
#include "filehdr.h"

//----------------------------------------------------------------------
// FileHeader::Allocate
// 	Initialize a fresh file header for a newly created file.
//	Allocate data blocks for the file out of the map of free disk blocks.
//	Return FALSE if there are not enough free blocks to accomodate
//	the new file.
//
//	"freeMap" is the bit map of free disk sectors
//	"fileSize" is the bit map of free disk sectors
//----------------------------------------------------------------------

bool
FileHeader::Allocate(BitMap *freeMap, int fileSize)//为文件分配磁盘块
{ 
    numBytes = fileSize;
    numSectors  = divRoundUp(fileSize, SectorSize);
    if (freeMap->NumClear() < numSectors)
	   return FALSE;		// not enough space
///////////////////////////////////////////////////////////////////////////////
if(numSectors>(NumDirect+NumNext)) return FALSE;
if(numSectors<=NumDirect)
    for (int i = 0; i < numSectors; i++)
	   dataSectors[i] = freeMap->Find();
else //if(numSectors>NumDirect)
{
 for (int i = 0; i < NumDirect; i++)
	 {  dataSectors[i] = freeMap->Find();/*printf("找到的一级块：%d  ",dataSectors[i]);*/}
 next=freeMap->Find();
 for (int i = 0; i < (numSectors-NumDirect); i++)
	  { moreSectors[i] = freeMap->Find();/*printf("找到的二级块：%d  ",moreSectors[i]);*/}
}
/////////////////////////////////////////////////////////////////////////////////
    return TRUE;
}
bool
FileHeader::Update(BitMap *freeMap, int addSize)//为文件分配磁盘块
{ 
    numBytes = numBytes+addSize;
    int Sectors  = numSectors;printf("已经使用 %d  sectors\n",Sectors);
    numSectors  = divRoundUp(numBytes, SectorSize);
    int numNeeded;
    if(Sectors<=NumDirect&&numSectors>NumDirect)
      numNeeded=numSectors-Sectors+1;
    else 
      numNeeded=numSectors-Sectors;
    if (freeMap->NumClear() < numNeeded||numSectors>(NumDirect+NumNext))
	return FALSE;		
    printf("需要 %d sectors\n",numNeeded);// not enough space
///////////////////////////////////////////////////////////////////////////////
//if(numSectors>(NumDirect+NumNext)||) return FALSE;//printf("需要 %d sectors\n",moreSector);
if(numSectors<=NumDirect)
    for (int i = 0; i < numNeeded; i++)
	  { dataSectors[Sectors+i] = freeMap->Find();/*printf("%d \n",dataSectors[Sectors+i]);*/}
else //if(numSectors>NumDirect)
{
if(Sectors<=NumDirect){
  for (int i = 0; i < (NumDirect-Sectors); i++)
	  dataSectors[Sectors+i] = freeMap->Find();
     next=freeMap->Find();
  for (int j= 0;j < (numSectors-NumDirect); j++)
	  {moreSectors[j] = freeMap->Find();}
}
else
{
for (int j= 0;j < (numSectors-Sectors); j++)
	  {moreSectors[Sectors-NumDirect+j] = freeMap->Find();}
}
}
/////////////////////////////////////////////////////////////////////////////////

    return TRUE;
}

//----------------------------------------------------------------------
// FileHeader::Deallocate
// 	De-allocate all the space allocated for data blocks for this file.
//
//	"freeMap" is the bit map of free disk sectors
//----------------------------------------------------------------------

void 
FileHeader::Deallocate(BitMap *freeMap)
{
if(numSectors<=NumDirect)
{
   for (int i = 0; i < numSectors; i++) {
	ASSERT(freeMap->Test((int) dataSectors[i]));  // ought to be marked!
	freeMap->Clear((int) dataSectors[i]);
    }
}
else //if(numSectors>NumDirect)
{
   for (int i = 0; i < NumDirect; i++) {
	ASSERT(freeMap->Test((int) dataSectors[i]));  // ought to be marked!
	freeMap->Clear((int) dataSectors[i]);
    }freeMap->Clear((int)next);
  for (int i = 0; i < (numSectors-NumDirect); i++) {
	ASSERT(freeMap->Test((int) moreSectors[i]));  // ought to be marked!
	freeMap->Clear((int) moreSectors[i]);
    }
}

}

//----------------------------------------------------------------------
// FileHeader::FetchFrom
// 	Fetch contents of file header from disk. 
//
//	"sector" is the disk sector containing the file header
//----------------------------------------------------------------------

void
FileHeader::FetchFrom(int sector)
{
    synchDisk->ReadSector(sector, (char *)this);
/////////////////////////////////////////////////////////////////////////////////////////////////////////
if(numSectors>NumDirect)
   {
    synchDisk->ReadSector(next,(char *)moreSectors);//printf("from%d        %d          %d\n",next,moreSectors[0],moreSectors);

   }
/////////////////////////////////////////////////////////////////////////////////////////////////////////
}

//----------------------------------------------------------------------
// FileHeader::WriteBack
// 	Write the modified contents of the file header back to disk. 
//
//	"sector" is the disk sector to contain the file header
//----------------------------------------------------------------------

void
FileHeader::WriteBack(int sector)
{
    synchDisk->WriteSector(sector, (char *)this); //printf("this%d       \n",(char *)this);
/////////////////////////////////////////////////////////////////////////////////////////////////////////
if(numSectors>NumDirect)
   {
    synchDisk->WriteSector(next,(char *)moreSectors);
   }
/////////////////////////////////////////////////////////////////////////////////////////////////////////
}

//----------------------------------------------------------------------
// FileHeader::ByteToSector
// 	Return which disk sector is storing a particular byte within the file.
//      This is essentially a translation from a virtual address (the
//	offset in the file) to a physical address (the sector where the
//	data at the offset is stored).
//
//	"offset" is the location within the file of the byte in question
//----------------------------------------------------------------------

int
FileHeader::ByteToSector(int offset)
{
   if(offset<(NumDirect*SectorSize))
    return(dataSectors[offset / SectorSize]);
   return(moreSectors[(offset-NumDirect*SectorSize)/SectorSize]); 
}

//----------------------------------------------------------------------
// FileHeader::FileLength
// 	Return the number of bytes in the file.
//----------------------------------------------------------------------

int
FileHeader::FileLength()
{
    return numBytes;
}

//----------------------------------------------------------------------
// FileHeader::Print
// 	Print the contents of the file header, and the contents of all
//	the data blocks pointed to by the file header.
//----------------------------------------------------------------------

void
FileHeader::Print()
{
    int i, j, k;
    char *data = new char[SectorSize];

    printf("文件头内容.  文件大小: %d.  一级索引:\n", numBytes);
if(numSectors<=NumDirect){
    for (i = 0; i < numSectors; i++)
	printf("%d ", dataSectors[i]);
    printf("\n文件内容:\n");
    for (i = k = 0; i < numSectors; i++) {
	synchDisk->ReadSector(dataSectors[i], data);
        for (j = 0; (j < SectorSize) && (k < numBytes); j++, k++) {
	    if ('\040' <= data[j] && data[j] <= '\176')   // isprint(data[j])
		printf("%c", data[j]);
            else
		printf("\\%x", (unsigned char)data[j]);
	}
        printf("\n"); 
    }
}
else{
for (i = 0; i < NumDirect; i++)
	printf("%d ", dataSectors[i]);
printf("\n二级索引存放在：%d",next);
printf("\n二级索引:");
for (int a=0; a < (numSectors-NumDirect); a++)
	printf("%d ", moreSectors[a]);

    printf("\n文件内容:\n");
    for (i = k = 0; i < NumDirect; i++) {
	synchDisk->ReadSector(dataSectors[i], data);
        for (j = 0; (j < SectorSize) && (k < numBytes); j++, k++) {
	    if ('\040' <= data[j] && data[j] <= '\176')   // isprint(data[j])
		printf("%c", data[j]);
            else
		printf("\\%x", (unsigned char)data[j]);
	}printf("\n");
     }
    for (i = k = 0; i < (numSectors-NumDirect); i++) {
	synchDisk->ReadSector(moreSectors[i], data);
        for (j = 0; (j < SectorSize) && (k < numBytes); j++, k++) {
	    if ('\040' <= data[j] && data[j] <= '\176')   // isprint(data[j])
		printf("%c", data[j]);
            else
		printf("\\%x", (unsigned char)data[j]);
	}
        printf("\n");
     } 
}
    delete [] data;
}
