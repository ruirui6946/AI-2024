arch/unknown-i386-linux/depends/filehdr.d arch/unknown-i386-linux/objects/filehdr.o: filehdr.cc ../threads/copyright.h ../threads/system.h \
  ../threads/copyright.h ../threads/utility.h ../threads/bool.h \
  ../machine/sysdep.h ../threads/copyright.h ../threads/thread.h \
  ../threads/scheduler.h ../threads/list.h ../machine/interrupt.h \
  ../threads/list.h ../machine/stats.h ../machine/timer.h \
  ../threads/utility.h ../lab5/filesys.h ../threads/copyright.h \
  ../lab5/openfile.h ../threads/utility.h ../lab5/synchdisk.h \
  ../machine/disk.h ../threads/synch.h filehdr.h ../machine/disk.h \
  ../userprog/bitmap.h ../threads/copyright.h ../threads/utility.h \
  ../lab5/openfile.h
