arch/unknown-i386-linux/depends/synch.d arch/unknown-i386-linux/objects/synch.o: ../threads/synch.cc ../threads/copyright.h ../threads/synch.h \
  ../threads/thread.h ../threads/utility.h ../threads/bool.h \
  ../machine/sysdep.h ../threads/copyright.h ../threads/list.h \
  ../threads/system.h ../threads/scheduler.h ../machine/interrupt.h \
  ../threads/list.h ../machine/stats.h ../machine/timer.h \
  ../threads/utility.h ../lab11/filesys.h ../threads/copyright.h \
  ../lab11/openfile.h ../threads/utility.h ../lab11/synchdisk.h \
  ../machine/disk.h ../threads/synch.h
