arch/unknown-i386-linux/depends/membitmap.d arch/unknown-i386-linux/objects/membitmap.o: ../machine/membitmap.cc ../threads/copyright.h \
  ../machine/membitmap.h ../threads/utility.h ../threads/copyright.h \
  ../threads/bool.h ../machine/sysdep.h ../filesys/openfile.h \
  ../threads/copyright.h ../threads/utility.h
