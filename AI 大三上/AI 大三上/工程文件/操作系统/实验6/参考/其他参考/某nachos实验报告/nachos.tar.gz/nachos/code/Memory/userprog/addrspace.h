// addrspace.h 
//	Data structures to keep track of executing user programs 
//	(address spaces).
//
//	For now, we don't keep any information about address spaces.
//	The user level CPU state is saved and restored in the thread
//	executing the user program (see thread.h).
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#ifndef ADDRSPACE_H
#define ADDRSPACE_H

#include "copyright.h"
#include "filesys.h"
#include "noff.h"

#define UserStackSize		2048 	

class AddrSpace {
  // added 10-30-96 KWR: lets my test case code access AddrSpace internals
  friend void TestCase(int);

  public:
    AddrSpace(OpenFile *fileDescriptor);  	// Create an address space,
					// initializing it with the program
					// stored in the file "executable"
    ~AddrSpace();			// De-allocate an address space

    void InitRegisters();		// Initialize user-level CPU registers,
					// before jumping to user code

    void SaveState();			// Save/restore address space-specific
    void RestoreState();		// info on a context switch 

    TranslationEntry *pageTable;	// Assume linear page table translation
					// for now!
    unsigned int numPages;		// Number of pages in the virtual 
					// address space
    void ReadSourcePage(char *buffer, unsigned virtualPage);
                                        // Read the virtual page into buffer. 
                                        // The page is read from the source file.

  private:
    char check[512];
    OpenFile *executable;
    NoffHeader noffH;
    unsigned int BeginCodePage, EndCodeAddr, EndCodePage, 
                 BeginInitDataPage, EndInitDataAddr, EndInitDataPage,
                 BeginUninitDataPage, EndUninitDataAddr, EndUninitDataPage,
                 BeginStackPage, EndStackAddr, EndStackPage;
};

#endif // ADDRSPACE_H
