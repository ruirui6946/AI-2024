arch/unknown-i386-linux/depends/openfile.d arch/unknown-i386-linux/objects/openfile.o: openfile.cc ../threads/copyright.h filehdr.h \
  ../machine/disk.h ../threads/copyright.h ../threads/utility.h \
  ../threads/copyright.h ../threads/bool.h ../machine/sysdep.h \
  ../userprog/bitmap.h ../threads/copyright.h ../threads/utility.h \
  ../filesys/openfile.h ../threads/copyright.h ../threads/utility.h \
  openfile.h ../threads/system.h ../threads/utility.h ../threads/thread.h \
  ../threads/scheduler.h ../threads/list.h ../machine/interrupt.h \
  ../threads/list.h ../machine/stats.h ../machine/timer.h \
  ../filesys/filesys.h ../filesys/openfile.h ../filesys/synchdisk.h \
  ../machine/disk.h ../threads/synch.h
