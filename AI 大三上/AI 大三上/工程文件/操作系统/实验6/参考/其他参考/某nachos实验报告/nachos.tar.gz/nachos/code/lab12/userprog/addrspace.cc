// addrspace.cc 
//	Routines to manage address spaces (executing user programs).
//
//	In order to run a user program, you must:
//
//	1. link with the -N -T 0 option 
//	2. run coff2noff to convert the object file to Nachos format
//		(Nachos object code format is essentially just a simpler
//		version of the UNIX executable object code format)
//	3. load the NOFF file into the Nachos file system
//		(if you haven't implemented the file system yet, you
//		don't need to do this last step)
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"
#include "addrspace.h"
#include "noff.h"
//#include "bitmap.h"
//extern BitMap *map;
//----------------------------------------------------------------------
// SwapHeader
// 	Do little endian to big endian conversion on the bytes in the 
//	object file header, in case the file was generated on a little
//	endian machine, and we're now running on a big endian machine.
//----------------------------------------------------------------------


//extern bool usable[32];
//usable={true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true,true};
static void 
SwapHeader (NoffHeader *noffH)
{

	noffH->noffMagic = WordToHost(noffH->noffMagic);
	noffH->code.size = WordToHost(noffH->code.size);
	noffH->code.virtualAddr = WordToHost(noffH->code.virtualAddr);
	noffH->code.inFileAddr = WordToHost(noffH->code.inFileAddr);
	noffH->initData.size = WordToHost(noffH->initData.size);
	noffH->initData.virtualAddr = WordToHost(noffH->initData.virtualAddr);
	noffH->initData.inFileAddr = WordToHost(noffH->initData.inFileAddr);
	noffH->uninitData.size = WordToHost(noffH->uninitData.size);
	noffH->uninitData.virtualAddr = WordToHost(noffH->uninitData.virtualAddr);
	noffH->uninitData.inFileAddr = WordToHost(noffH->uninitData.inFileAddr);
}

//----------------------------------------------------------------------
// AddrSpace::AddrSpace
// 	Create an address space to run a user program.
//	Load the program from a file "executable", and set everything
//	up so that we can start executing user instructions.
//
//	Assumes that the object code file is in NOFF format.
//
//	First, set up the translation from program memory to physical 
//	memory.  For now, this is really simple (1:1), since we are
//	only uniprogramming, and we have a single unsegmented page table
//
//	"executable" is the file containing the object code to load into memory
//----------------------------------------------------------------------

AddrSpace::AddrSpace(OpenFile *executable)
{
    NoffHeader noffH;
      unsigned int i, j, size;
 int tmp,pos;
 char* buffer;
executable->ReadAt((char *)&noffH, sizeof(noffH), 0);
    if ((noffH.noffMagic != NOFFMAGIC) && 
		(WordToHost(noffH.noffMagic) == NOFFMAGIC))
    	SwapHeader(&noffH);
    ASSERT(noffH.noffMagic == NOFFMAGIC);

// how big is address space?
    size = noffH.code.size + noffH.initData.size + noffH.uninitData.size 
			+ UserStackSize;	// we need to increase the size
						// to leave room for the stack
printf("\n******************************************\n");
printf("code :%d\n",noffH.code.size);
printf("initData :%d\n",noffH.initData.size);
printf("uninitData :%d\n",noffH.uninitData.size );
printf("UserStackSize :%d\n",UserStackSize);
printf("total size :%d\n",size);
printf("\n******************************************\n");
    numPages = divRoundUp(size, PageSize);

    size = numPages * PageSize;
    //ASSERT(numPages <= map->NumClear());		// check we're not trying
						// to run anything too big --
						// at least until we have
						// virtual memory

    DEBUG('a', "Initializing address space, num pages %d, size %d\n", 
					numPages, size);
// first, set up the translation 
    pageTable = new TranslationEntry[numPages];
    /*unsigned int i, size;
    
    unsigned int code_numP,code_firstP,
				initData_numP,initData_firstP;
    executable->ReadAt((char *)&noffH, sizeof(noffH), 0);
    if ((noffH.noffMagic != NOFFMAGIC) && 
		(WordToHost(noffH.noffMagic) == NOFFMAGIC))
    	SwapHeader(&noffH);
    ASSERT(noffH.noffMagic == NOFFMAGIC);

// how big is address space?
    size = noffH.code.size + noffH.initData.size + noffH.uninitData.size 
			+ UserStackSize;	// we need to increase the size
						// to leave room for the stack
printf("\n******************************************\n");
printf("code :%d\n",noffH.code.size);
printf("initData :%d\n",noffH.initData.size);
printf("uninitData :%d\n",noffH.uninitData.size );
printf("UserStackSize :%d\n",UserStackSize);
printf("total size :%d\n",size);
printf("\n******************************************\n");
    numPages = divRoundUp(size, PageSize);

    size = numPages * PageSize;
    ASSERT(numPages <= map->NumClear());		// check we're not trying
						// to run anything too big --
						// at least until we have
						// virtual memory

    DEBUG('a', "Initializing address space, num pages %d, size %d\n", 
					numPages, size);
// first, set up the translation 
    pageTable = new TranslationEntry[numPages];

    for (i = 0; i < numPages; i++) {
	pageTable[i].virtualPage = i;	// for now, virtual page # = phys page #
	pageTable[i].physicalPage = map->Find();
	pageTable[i].valid = TRUE;
	pageTable[i].use = FALSE;
	pageTable[i].dirty = FALSE;
	pageTable[i].readOnly = FALSE;  // if the code segment was entirely on 
					// a separate page, we could set its 
					// pages to be read-only
    }
    
// zero out the entire address space, to zero the unitialized data segment 
// and the stack segment
    //bzero(machine->mainMemory, size);

// then, copy in the code and data segments into memory
    if (noffH.code.size > 0) {
        DEBUG('a', "Initializing code segment, at 0x%x, size %d\n", 
			noffH.code.virtualAddr, noffH.code.size);
     code_numP=divRoundUp(noffH.code.size,PageSize);
     code_firstP=divRoundUp(noffH.code.virtualAddr,PageSize);
     for(int i1=code_firstP;i1<code_numP;i1++)
        executable->ReadAt(&(machine->mainMemory[pageTable[i1].physicalPage*PageSize]),
			PageSize, noffH.code.inFileAddr+i1*PageSize);
    }
    if (noffH.initData.size > 0) {
        DEBUG('a', "Initializing data segment, at 0x%x, size %d\n", 
			noffH.initData.virtualAddr, noffH.initData.size);
      initData_numP=divRoundUp(noffH.initData.size,PageSize);
      initData_firstP=divRoundUp(noffH.initData.virtualAddr,PageSize);
      for(int i2=initData_firstP;i2<initData_numP;i2++)
        executable->ReadAt(&(machine->mainMemory[pageTable[i2].physicalPage*PageSize]),
			PageSize, noffH.initData.inFileAddr+i2*PageSize);
    }
Print();*/


     //ASSERT(numPages <= NumPhysPages);        // check we're not trying

 //With VM Support :)
 //     ASSERT(numPages <= NumPhysPages);     // check we're not trying

 //Modified by Grubby

     for (i = 0; i < numPages; i++) 
            {
 pageTable[i].virtualPage = i; // for now, virtual page # = phys page #
 pageTable[i].physicalPage = i;
 pageTable[i].valid = TRUE;
 pageTable[i].use = FALSE;
 pageTable[i].dirty = FALSE;
 pageTable[i].readOnly = FALSE; // if the code segment was entirely on
                   // a separate page, we could set its
                   // pages to be read-only
            }

 // zero out the entire address space, to zero the unitialized data segment
 // and the stack segment
     bzero(machine->mainMemory, size);

 // then, copy in the code and data segments into memory
     if (noffH.code.size > 0) {
          DEBUG('a', "Initializing code segment, at 0x%x, size %d\n",
           noffH.code.virtualAddr, noffH.code.size);executable->ReadAt(&(machine->mainMemory[noffH.code.virtualAddr]),noffH.code.size, noffH.code.inFileAddr);

     for (i = 0; i < numPages; i++)
     {
     //  pageTable[i].virtualPage = -1;     //物理内存优先载入
        //printf("kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk\n");   
       tmp=machine->MemPageTable->Find(); //找到一个可用的页面

       if(tmp!=-1)
      {
           machine->MemPageTable->Set(tmp);
           machine->MemPageTable->SetCounter(tmp,0);
           machine->MemPageTable->SetTime(tmp,stats->totalTicks);
           machine->MemPageTable->SetOwner(tmp,(int*)currentThread);
       }
       pageTable[i].physicalPage = tmp;
       pageTable[i].valid = TRUE;

       if(tmp==-1)
       {printf("物理内存满，分配虚拟\n");
           //物理内存中可用页已满，则装入虚拟存储器
           pos=machine->vm->Find();
           //若虚拟内存已满，报错退出
           if(pos==-1)
           {
               printf("虚拟内存已满！Exit...");
               ASSERT(pos!=-1);
           }
           machine->vm->Mark(pos);
           pageTable[i].virtualPage = pos;
           pageTable[i].valid=FALSE;
       }
       pageTable[i].use = FALSE;
       pageTable[i].dirty = FALSE;
       pageTable[i].readOnly = FALSE; // if the code segment was entirely on
                                      // a separate page, we could set its
                                      // pages to be read-only
       pageTable[i].counter=0;//初始化为 0
       pageTable[i].time=stats->totalTicks;//初始化为当前时钟
     }
}
     //从执行文件读入缓冲区
     buffer=new char[size];
 //缓冲区清 0
 bzero(buffer,size);
     if (noffH.code.size > 0)
{

executable->ReadAt(&(buffer[noffH.code.virtualAddr]),noffH.code.size,
noffH.code.inFileAddr);

         DEBUG('a', "Initializing data segment, at 0x%x, size %d\n",
           noffH.initData.virtualAddr, noffH.initData.size);

executable->ReadAt(&(machine->mainMemory[noffH.initData.virtualAddr]),
           noffH.initData.size, noffH.initData.inFileAddr);
executable->ReadAt(&(buffer[noffH.initData.virtualAddr]),noffH.initData.size, noffH.initData.inFileAddr);
printf("中断返回\n");
     for(i=0;i<numPages;i++)
     {
       if(pageTable[i].valid==TRUE)
       {
           //载入物理内存
           j=0;
           for(j=0;j<PageSize;j++)
           {

    machine->mainMemory[(pageTable[i].physicalPage)*PageSize+j]=buffer[i*PageSize+j];
               //...还应刷新计数器＆记录访问时间
           }
       }
       else
       {
           //载入虚拟内存>           DEBUG('a', "Loading into Vm...\n");
printf("中断返回2\n");
    machine->vm->Write(pageTable[i].virtualPage,buffer+(i*PageSize));
       }
}
 
printf("中断返回3\n");
}
//delete buffer;
Print();
}

//----------------------------------------------------------------------
// AddrSpace::~AddrSpace
// 	Dealloate an address space.  Nothing for now!
//----------------------------------------------------------------------

AddrSpace::~AddrSpace()
{
   delete [] pageTable;
}

//----------------------------------------------------------------------
// AddrSpace::InitRegisters
// 	Set the initial values for the user-level register set.
//
// 	We write these directly into the "machine" registers, so
//	that we can immediately jump to user code.  Note that these
//	will be saved/restored into the currentThread->userRegisters
//	when this thread is context switched out.
//----------------------------------------------------------------------

void
AddrSpace::InitRegisters()
{
    int i;

    for (i = 0; i < NumTotalRegs; i++)
	machine->WriteRegister(i, 0);

    // Initial program counter -- must be location of "Start"
    machine->WriteRegister(PCReg, 0);	

    // Need to also tell MIPS where next instruction is, because
    // of branch delay possibility
    machine->WriteRegister(NextPCReg, 4);

   // Set the stack register to the end of the address space, where we
   // allocated the stack; but subtract off a bit, to make sure we don't
   // accidentally reference off the end!
    machine->WriteRegister(StackReg, numPages * PageSize - 16);
    DEBUG('a', "Initializing stack register to %d\n", numPages * PageSize - 16);
}

//----------------------------------------------------------------------
// AddrSpace::SaveState
// 	On a context switch, save any machine state, specific
//	to this address space, that needs saving.
//
//	For now, nothing!
//----------------------------------------------------------------------

void AddrSpace::SaveState() 
{}

//----------------------------------------------------------------------
// AddrSpace::RestoreState
// 	On a context switch, restore the machine state so that
//	this address space can run.
//
//      For now, tell the machine where to find the page table.
//----------------------------------------------------------------------

void AddrSpace::RestoreState() 
{
    machine->pageTable = pageTable;
    machine->pageTableSize = numPages;
}
void
AddrSpace::Print()
{
printf("\n******************************************\n");
printf("page table dump:%d pages in total\n",numPages);
printf("\nVirtualPages,         PhysicalPages\n");
for(int i=0;i<numPages;i++)
{
printf("\t%d, \t\t%d\n",pageTable[i].virtualPage,pageTable[i].physicalPage);
}
printf("\n******************************************\n");
printf("\n******************************************\n");
//printf("number of clear pages :%d",map->NumClear());
printf("\n******************************************\n");

}
