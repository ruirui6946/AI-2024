arch/unknown-i386-linux/depends/synchtest.d arch/unknown-i386-linux/objects/synchtest.o: ../threads/synchtest.cc ../threads/copyright.h \
  ../threads/system.h ../threads/utility.h ../threads/bool.h \
  ../machine/sysdep.h ../threads/copyright.h ../threads/thread.h \
  ../machine/machine.h ../threads/utility.h ../machine/translate.h \
  ../machine/disk.h ../machine/virtualmem.h ../filesys/openfile.h \
  ../threads/copyright.h ../threads/utility.h ../machine/bitmap.h \
  ../machine/membitmap.h ../userprog/addrspace.h ../threads/copyright.h \
  ../filesys/filesys.h ../filesys/openfile.h ../threads/scheduler.h \
  ../threads/list.h ../machine/interrupt.h ../threads/list.h \
  ../machine/stats.h ../machine/timer.h ../filesys/filesys.h \
  ../threads/synch.h
