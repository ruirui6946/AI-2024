arch/unknown-i386-linux/depends/virtualmem.d arch/unknown-i386-linux/objects/virtualmem.o: ../machine/virtualmem.cc ../threads/copyright.h \
  ../machine/virtualmem.h ../threads/utility.h ../threads/copyright.h \
  ../threads/bool.h ../machine/sysdep.h ../filesys/openfile.h \
  ../threads/copyright.h ../threads/utility.h ../machine/bitmap.h
