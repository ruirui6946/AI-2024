// threadtest.cc 
//	Simple test case for the threads assignment.
//
//	Create two threads, and have them context switch
//	back and forth between themselves by calling Thread::Yield, 
//	to illustratethe inner workings of the thread system.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "system.h"

//----------------------------------------------------------------------
// SimpleThread
// 	Loop 5 times, yielding the CPU to another ready thread 
//	each iteration.
//
//	"which" is simply a number identifying the thread, for debugging
//	purposes.
//----------------------------------------------------------------------



void
SimpleThread(_int which)
{
    int num;
    for (num = 0; num < 5; num++) {
printf("### 线程 %s %d 优先级为 %d 循环了 %d 次\n", currentThread->getName(), (int)which,currentThread->getPriority(),num);
    currentThread->Yield();//优先级
    }
}


//----------------------------------------------------------------------
// ThreadTest
// 	Set up a ping-pong between two threads, by forking a thread 
//	to call SimpleThread, and then calling SimpleThread ourselves.
//----------------------------------------------------------------------

void
ThreadTest()
{ DEBUG('t', "Entering SimpleTest");
currentThread->setPriority(7);
currentThread->setName("main    thread");
Thread *t = new Thread("forked  thread");t->setPriority(13);
t->Fork(SimpleThread, 2);
Thread *x = new Thread("another thread");x->setPriority(5);
x->Fork(SimpleThread, 3);
SimpleThread(1);
printf("end main\n");
}


