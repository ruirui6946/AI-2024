arch/unknown-i386-linux/depends/scheduler.d arch/unknown-i386-linux/objects/scheduler.o: scheduler.cc ../threads/copyright.h scheduler.h \
  ../threads/list.h ../threads/copyright.h ../threads/utility.h \
  ../threads/bool.h ../machine/sysdep.h ../threads/copyright.h \
  ../threads/thread.h system.h ../threads/utility.h \
  ../machine/interrupt.h ../threads/list.h ../machine/stats.h \
  ../machine/timer.h ../threads/utility.h
