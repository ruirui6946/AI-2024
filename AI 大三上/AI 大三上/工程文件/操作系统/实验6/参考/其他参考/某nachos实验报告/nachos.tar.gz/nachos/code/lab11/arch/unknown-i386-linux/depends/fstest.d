arch/unknown-i386-linux/depends/fstest.d arch/unknown-i386-linux/objects/fstest.o: fstest.cc ../threads/copyright.h ../threads/utility.h \
  ../threads/copyright.h ../threads/bool.h ../machine/sysdep.h \
  ../threads/copyright.h filesys.h openfile.h ../threads/system.h \
  ../threads/utility.h ../threads/thread.h ../threads/scheduler.h \
  ../threads/list.h ../machine/interrupt.h ../threads/list.h \
  ../machine/stats.h ../machine/timer.h ../threads/utility.h \
  ../lab11/filesys.h ../lab11/synchdisk.h ../threads/copyright.h \
  ../machine/disk.h ../threads/synch.h ../threads/thread.h \
  ../machine/disk.h ../machine/stats.h ../userprog/bitmap.h \
  ../threads/copyright.h ../threads/utility.h ../lab11/openfile.h \
  directory.h
