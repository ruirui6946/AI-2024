arch/unknown-i386-linux/depends/sysdep.d arch/unknown-i386-linux/objects/sysdep.o: ../machine/sysdep.cc ../threads/copyright.h \
  ../machine/interrupt.h ../threads/list.h ../threads/copyright.h \
  ../threads/utility.h ../threads/bool.h ../machine/sysdep.h \
  ../threads/system.h ../threads/thread.h ../threads/scheduler.h \
  ../threads/list.h ../machine/interrupt.h ../machine/stats.h \
  ../machine/timer.h ../threads/utility.h ../lab5/filesys.h \
  ../threads/copyright.h ../lab5/openfile.h ../threads/utility.h \
  ../lab5/synchdisk.h ../machine/disk.h ../threads/synch.h
