arch/unknown-i386-linux/depends/directory.d arch/unknown-i386-linux/objects/directory.o: directory.cc ../threads/copyright.h ../threads/utility.h \
  ../threads/copyright.h ../threads/bool.h ../machine/sysdep.h \
  ../threads/copyright.h filehdr.h ../machine/disk.h ../threads/utility.h \
  ../userprog/bitmap.h ../threads/copyright.h ../threads/utility.h \
  ../filesys/openfile.h ../threads/copyright.h ../threads/utility.h \
  directory.h openfile.h
