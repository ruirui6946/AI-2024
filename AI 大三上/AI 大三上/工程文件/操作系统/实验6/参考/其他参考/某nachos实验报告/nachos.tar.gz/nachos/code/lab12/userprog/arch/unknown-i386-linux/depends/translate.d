arch/unknown-i386-linux/depends/translate.d arch/unknown-i386-linux/objects/translate.o: ../machine/translate.cc ../threads/copyright.h \
  ../machine/machine.h ../threads/utility.h ../threads/copyright.h \
  ../threads/bool.h ../machine/sysdep.h ../machine/translate.h \
  ../machine/disk.h ../machine/virtualmem.h ../filesys/openfile.h \
  ../threads/copyright.h ../threads/utility.h ../machine/bitmap.h \
  ../machine/membitmap.h ../userprog/addrspace.h ../threads/copyright.h \
  ../filesys/filesys.h ../filesys/openfile.h ../threads/system.h \
  ../threads/utility.h ../threads/thread.h ../machine/machine.h \
  ../userprog/addrspace.h ../threads/scheduler.h ../threads/list.h \
  ../machine/interrupt.h ../threads/list.h ../machine/stats.h \
  ../machine/timer.h ../filesys/filesys.h
