arch/unknown-i386-linux/depends/synchlist.d arch/unknown-i386-linux/objects/synchlist.o: ../threads/synchlist.cc ../threads/copyright.h \
  ../threads/synchlist.h ../threads/list.h ../threads/utility.h \
  ../threads/bool.h ../machine/sysdep.h ../threads/copyright.h \
  ../threads/synch.h ../threads/thread.h ../machine/machine.h \
  ../threads/utility.h ../machine/translate.h ../machine/disk.h \
  ../machine/virtualmem.h ../filesys/openfile.h ../threads/copyright.h \
  ../threads/utility.h ../machine/bitmap.h ../machine/membitmap.h \
  ../userprog/addrspace.h ../threads/copyright.h ../filesys/filesys.h \
  ../filesys/openfile.h
