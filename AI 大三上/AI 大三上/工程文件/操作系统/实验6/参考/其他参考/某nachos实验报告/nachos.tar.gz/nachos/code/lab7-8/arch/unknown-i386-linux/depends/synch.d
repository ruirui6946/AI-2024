arch/unknown-i386-linux/depends/synch.d arch/unknown-i386-linux/objects/synch.o: ../threads/synch.cc ../threads/copyright.h ../threads/synch.h \
  ../threads/thread.h ../threads/utility.h ../threads/bool.h \
  ../machine/sysdep.h ../threads/copyright.h ../machine/machine.h \
  ../threads/utility.h ../machine/translate.h ../machine/disk.h \
  ../userprog/addrspace.h ../threads/copyright.h ../filesys/filesys.h \
  ../threads/copyright.h ../filesys/openfile.h ../threads/utility.h \
  ../threads/list.h ../threads/system.h ../threads/scheduler.h \
  ../machine/timer.h ../machine/interrupt.h ../threads/list.h \
  ../machine/stats.h ../filesys/filesys.h
