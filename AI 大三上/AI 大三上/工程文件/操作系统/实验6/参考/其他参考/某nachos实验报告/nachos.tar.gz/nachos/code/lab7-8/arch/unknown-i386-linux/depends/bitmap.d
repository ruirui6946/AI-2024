arch/unknown-i386-linux/depends/bitmap.d arch/unknown-i386-linux/objects/bitmap.o: bitmap.cc ../threads/copyright.h bitmap.h ../threads/utility.h \
  ../threads/copyright.h ../threads/bool.h ../machine/sysdep.h \
  ../threads/copyright.h ../filesys/openfile.h ../threads/copyright.h \
  ../threads/utility.h
