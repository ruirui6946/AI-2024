arch/unknown-i386-linux/depends/thread.d arch/unknown-i386-linux/objects/thread.o: ../threads/thread.cc ../threads/copyright.h ../threads/thread.h \
  ../threads/utility.h ../threads/bool.h ../machine/sysdep.h \
  ../threads/copyright.h ../machine/machine.h ../threads/utility.h \
  ../machine/translate.h ../machine/disk.h ../machine/virtualmem.h \
  ../filesys/openfile.h ../threads/copyright.h ../threads/utility.h \
  ../machine/bitmap.h ../machine/membitmap.h ../userprog/addrspace.h \
  ../threads/copyright.h ../filesys/filesys.h ../filesys/openfile.h \
  ../threads/switch.h ../threads/synch.h ../threads/list.h \
  ../threads/system.h ../threads/scheduler.h ../machine/interrupt.h \
  ../threads/list.h ../machine/stats.h ../machine/timer.h \
  ../filesys/filesys.h
