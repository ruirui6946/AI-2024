arch/unknown-i386-linux/depends/system.d arch/unknown-i386-linux/objects/system.o: system.cc ../threads/copyright.h system.h ../threads/utility.h \
  ../threads/copyright.h ../threads/bool.h ../machine/sysdep.h \
  ../threads/copyright.h ../threads/thread.h ../threads/utility.h \
  scheduler.h ../threads/list.h ../machine/interrupt.h ../threads/list.h \
  ../machine/stats.h ../machine/timer.h ../threads/utility.h
